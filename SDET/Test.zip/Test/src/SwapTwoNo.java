
public class SwapTwoNo {

	public static void main(String[] args) {
		
		 int a= 10;
		 int b= 40;
		 
		 a =a+b;//10+40=50
		 b =a-b;//50-40=10
		 a=a-b;//50-10=40;
		 System.out.println("a :"+a);
		 System.out.println("b :"+b);
		 
		
	}
	
}
