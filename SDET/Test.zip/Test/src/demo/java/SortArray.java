package demo.java;

public class SortArray {

	public static void Sort(int[] arr) {

		for (int i = 0; i < arr.length; i++) {

			for (int j = i + 1; j < arr.length; j++) {

				int temp = 0;
				if (arr[i] < arr[j]) {

					temp = arr[i];

					arr[i] = arr[j];

					arr[j] = temp;

				}
				
			}

			System.out.print(arr[i] + " ");
		}

	}

	public static void main(String[] args) {

		int arr[] = { 6, 8, 2, 3, 1 };
		Sort(arr);

	}

}
