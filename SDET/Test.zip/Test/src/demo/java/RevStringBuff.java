package demo.java;

public class RevStringBuff {

	public static void main(String[] args) {

		String name = "Ganesh";
		StringBuffer name1= new StringBuffer();
		name1.append(name);
		name1.reverse();
		System.out.println(name1);
		
		
		
		
	}

}
